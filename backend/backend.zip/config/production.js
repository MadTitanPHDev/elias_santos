// Configurações para produção
module.exports = {
  // Configurações do Banco de Dados
  database: {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'u937729098_elias_santosdb',
    password: process.env.DB_PASSWORD || 'J7caWp;pit!t',
    database: process.env.DB_NAME || 'u937729098_elias_santosdb',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  },
  
  // Configurações JWT
  jwt: {
    secret: process.env.JWT_SECRET || 'seu_jwt_secret_super_seguro_aqui',
    expiresIn: '24h'
  },
  
  // Configurações do Servidor
  server: {
    port: process.env.PORT || 5000,
    nodeEnv: process.env.NODE_ENV || 'production'
  },
  
  // URL do Frontend (para CORS)
  frontend: {
    url: process.env.FRONTEND_URL || 'https://seudominio.com'
  }
};
