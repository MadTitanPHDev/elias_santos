// backend/config/database.js
const mysql = require('mysql2');

const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'u937729098_elias_santosdb',
    password: process.env.DB_PASSWORD || 'J7caWp;pit!t',
    database: process.env.DB_NAME || 'u937729098_elias_santosdb',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};

// Criar pool de conexões
const pool = mysql.createPool(dbConfig);

// Promisify para usar async/await
const promisePool = pool.promise();

module.exports = promisePool;